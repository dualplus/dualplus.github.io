RAF model
vgg16:  59.89
patch + full body, no gate 63.54
patch, no gate 65.10

patch + full body + gate 61.19
patch + gate   59.79



Affect model:
vgg16: 57.81

patch + full body, no gate
patch, no gate    59.11

patch + full body + gate  62.66
patch + gate   63.28